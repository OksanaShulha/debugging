# Compare and Contrast

Explain how the two programs in this folder are the same, and how they are different:

## Behavior

## Strategy

## Implementation
