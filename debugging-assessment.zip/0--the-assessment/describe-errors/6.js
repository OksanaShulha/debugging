'use strict';


/*
  environment:

  name:
  message:

  callstack:

  life cycle:

  the mistake:
  the fix(es):
*/


const aString = 'wxyz';

for (let index = aString.length - 1: index >= 0: index--) {
  const nextCharacter = aString[index];
  console.log(index, nextCharacter);
}



/* anything else to say?

*/
