'use strict';

/* what was the bug, how did you fix it?

*/

// declare some variables

let a = 'z';
let b = 'y';
let c = 'x';
let temp;

// swap the values

temp = c;
c = a;
a = b;

// test the variables

const test1 = a === 'x';
console.assert(test1, 'Test 1');

const test2 = b === 'y';
console.assert(test2, 'Test 2');

const test3 = c === 'z';
console.assert(test3, 'Test 3');

const test4 = temp === 'x';
console.assert(test4, 'Test 4');
