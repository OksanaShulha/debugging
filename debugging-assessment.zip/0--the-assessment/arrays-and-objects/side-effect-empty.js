'use strict';

// this function is empty
//  write it!

/**
 *
 */
const addToItems = () => {};

// the tests are all correct!  write the function ^
const _1_expect = [];
const _1_actual = addToItems([], 0);
console.assert(deepCompare(_1_actual, _1_expect), '1. an empty array');

const _2_expect = [2, 3, 4];
const _2_actual = addToItems([1, 2, 3], 1);
console.assert(deepCompare(_2_actual, _2_expect), '2. add 1');

const _3_expect = [0, 1, 2, 3];
const _3_actual = addToItems([1, 2, 3, 4], -1);
console.assert(deepCompare(_3_actual, _3_expect), '3. add -1');

const _4_expect = [1, 2];
const _4_actual = addToItems([1, 2]);
console.assert(
  deepCompare(_4_actual, _4_expect),
  '4. second param defaults to 0'
);

const _5_expect = [];
const _5_actual = addToItems();
console.assert(
  deepCompare(_5_actual, _5_expect),
  '5. first param defaults to []'
);

const _6_argument = [1, 2, 3];
addToItems(_6_argument, 3);
console.assert(deepCompare(_6_argument, [1, 2, 3]), '6. has no side-effects');

// prettier-ignore
function deepCompare (actual, expect) {  return actual === expect || Object.is(actual, expect)|| (Object(actual) === actual && Object(expect) === expect) && (Array.isArray(actual) && Array.isArray(expect) && actual.length === expect.length && expect.every((expect, index) => deepCompare(actual[index], expect))|| Object.keys(actual).length === Object.keys(expect).length && Object.keys(expect).every((key) => deepCompare(actual[key], expect[key])));}
