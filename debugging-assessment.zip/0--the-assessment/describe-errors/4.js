'use strict';

/*
  environment:

  name:
  message:

  callstack:

  life cycle:

  the mistake:
  the fix(es):
*/

while (true) {
  const userInput = prompt('enter something to leave this loop');

  if (userInput !== null && userInput !== '') {
    return;
  }
}

/* anything else to say?

*/
