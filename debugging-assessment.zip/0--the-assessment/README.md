# Debugging Assessment: Class 13-14

Show yourself how much you've learned, and show us where you can still use some help.

---

## THIS IS INDIVIDUAL

**_do not_** collaborate on this assessment. This assessment is so we know how _you_ are doing, what _you_ have mastered, and what _you_ are struggling with. **_THERE WILL BE NO GRADES_**. We will use your results to get you the individual support you need and to adjust the course if necessary.

If you help each other on this or submit code you wrote with someone else, we will not know how _you_ are doing and what _you_ need help with. It wouldn't be very hard for you to trick us, but you'd only be hurting yourself.

---

## Expectations

- you may use all of your notes and the internet
- comment each file
  - write one block comment at the top of each file explaining the code, and any changes you made
  - use comments above as many lines as possible to describe how the code works
- complete as much as you can. if you aren't able to complete something let us know why with a comment.
  - did you run out of time?
  - did you not understand what you were supposed to do?
  - was the question too hard?
  - something else?
  - this information will help us help you
- use a linter and format your code! all code you write should be beautiful, even your markdown
- you do not need to use pull requests, project boards, or to work on separate branches. just compressing your folder and uploading it in the form will do

---

## Assessment Sections

The sections are described in alphabetical order, you don't need to work on them in any specific order. Just finish as much as you are able to in an order that makes sense to you. Our only request is that you at least start each folder so we can evaluate your work for each topic.

### Arrays and Objects

A few different types of exercises to show what you've learned:

- swapping arrays & objects between variables
- swapping values between arrays and objects
- bracket notation for objects
- side-effects in functions

### Compare and Contrast

You will be given two working programs with the same behavior, but different implementations. Complete these tasks:

- Comment both programs: one block comment up top, and many comments in the code to explain what is happening on each line and why each line is important in the program.
- write a README comparing and contrasting the programs' behaviors, strategies and implementations. (we will be checking your markdown for mistakes!)

### Describe Errors

Complete the structured comments in each file and add comments to show where the error and the mistake occurred.

### Fix Bugs

You will be given short scripts with failing assertions at the end:

- explain what was wrong in the block comment up top
- fix the code to pass the assertions
- comment your debugged solution with what/why comments

### Reverse-Engineer

you will be given an unreadable program, your task is to reverse-engineer it using whatever language features and strategies you are most comfortable with. You are not required to use functions, but that doesn't mean you can't try ;)
