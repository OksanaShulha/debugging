'use strict';

// -- declare variables (this is correct) --
let a = [1, 2, 3];
let b = ['x', 'y', 'z'];
let temp;

// -- swap values (write this code) --

// -- assert the values (this is correct) --
console.assert(
  deepCompare(a, ['x', 'y', 'z']),
  'a references the array with strings'
);
console.assert(
  deepCompare(b, [1, 2, 3]),
  'b references the array with numbers'
);

// prettier-ignore
function deepCompare (actual, expect) {  return actual === expect || Object.is(actual, expect)|| (Object(actual) === actual && Object(expect) === expect) && (Array.isArray(actual) && Array.isArray(expect) && actual.length === expect.length && expect.every((expect, index) => deepCompare(actual[index], expect))|| Object.keys(actual).length === Object.keys(expect).length && Object.keys(expect).every((key) => deepCompare(actual[key], expect[key])));}
