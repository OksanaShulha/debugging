'use strict';

// this function does not pass it's tests
//  fix it!

/**
 *
 * @param { } arr
 * @returns
 */
const reverseArray = arr => {
  arr.reverse();
  return arr;
};

// the tests are all correct!  fix the function ^
const _1_expect = [];
const _1_actual = reverseArray([]);
console.assert(deepCompare(_1_actual, _1_expect), '1. an empty array');

const _2_expect = [4, 3, 2, 1];
const _2_actual = reverseArray([1, 2, 3, 4]);
console.assert(deepCompare(_2_actual, _2_expect), '2. an array of numbers');

const _3_expect = ['c', 'b', 'a'];
const _3_actual = reverseArray(['a', 'b', 'c']);
console.assert(deepCompare(_3_actual, _3_expect), '3. an array of strings');

const _4_expect = [];
const _4_actual = reverseArray();
console.assert(deepCompare(_4_actual, _4_expect), '4. has a default parameter');

const _5_argument = [1, 2, 3];
reverseArray(_5_argument);
console.assert(deepCompare(_5_argument, [1, 2, 3]), '5. has no side-effects');

// prettier-ignore
function deepCompare (actual, expect) {  return actual === expect || Object.is(actual, expect)|| (Object(actual) === actual && Object(expect) === expect) && (Array.isArray(actual) && Array.isArray(expect) && actual.length === expect.length && expect.every((expect, index) => deepCompare(actual[index], expect))|| Object.keys(actual).length === Object.keys(expect).length && Object.keys(expect).every((key) => deepCompare(actual[key], expect[key])));}
