'use strict';

/*
  (your notes here)
*/

// --- declare functions (optional) ---

// --- main program (required) ---

// - gather user input -

// - process the input -

// - alert final result -

