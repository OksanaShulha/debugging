'use strict';

/*
  environment:

  name:
  message:

  callstack:

  life cycle:

  the mistake:
  the fix(es):
*/

const aFunction = 'hello!';
aFunction();

/* anything else to say?

*/
