'use strict';

/* what was the bug? how did you fix it?

*/

let userNumber = NaN;
while (true) {
  const userInput = prompt('enter a number');

  if (userInput !== null || userInput !== '') {
    alert('please enter something');
    continue;
  }

  userNumber = Number(userInput);
  if (typeof userNumber === 'number') {
    break;
  }
}

// should never alert NaN
const numberAlert = 'you entered the number ' + userNumber;
alert(numberAlert);
