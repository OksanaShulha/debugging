'use strict';

// -- declare variables (this is correct) --
let a = { a: 1, b: 2, c: 3 };
let b = { a: 'x', b: 'y', c: 'z' };
let temp;

// -- swap values (write this code) --

// -- assert the values (this is correct) --
console.assert(
  deepCompare(a, { a: 'x', b: 'y', c: 'z' }),
  'a references the object with strings'
);
console.assert(
  deepCompare(b, { a: 1, b: 2, c: 3 }),
  'b references the object with numbers'
);

// prettier-ignore
function deepCompare (actual, expect) {  return actual === expect || Object.is(actual, expect)|| (Object(actual) === actual && Object(expect) === expect) && (Array.isArray(actual) && Array.isArray(expect) && actual.length === expect.length && expect.every((expect, index) => deepCompare(actual[index], expect))|| Object.keys(actual).length === Object.keys(expect).length && Object.keys(expect).every((key) => deepCompare(actual[key], expect[key])));}
